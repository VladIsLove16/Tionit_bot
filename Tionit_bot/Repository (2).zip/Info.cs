﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tionit_bot
{
    internal class Info
    {
        public string Username=" ";
        public int TheshId=0;
        public int ChatId=0;
        public Info() { }
    }
}
